# Prototype
This is the code for your interface prototype should sit. I have created a suggested structure for you using HTML5 boiler plate. Do not feel that you have to use this, but any structure you do use should use appropriate directory names. If you want to use Initilizer to set up a quick structure like this go ahead it will help you set up default Bootstrap profiles as well. http://www.initializr.com/
Be warned though do non submit a non-customised css template or framework as you will not get many marks for it.
